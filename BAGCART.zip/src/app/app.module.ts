import { HomePage } from './../pages/home/home';
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { TabsPage } from '../pages/tabs/tabs';
import {AngularFireModule} from 'angularfire2';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { ContactPage } from '../pages/contact/contact';
import { AboutPage } from '../pages/about/about';
import{FIREBASE_CONFIG} from "./app.firebase.config";
import{AngularFireAuthModule} from "angularfire2/auth";
import{AngularFireAuth} from "angularfire2/auth";
import { CommonProvider } from '../providers/common/common';
@NgModule({
  declarations: [
     MyApp,
    TabsPage,HomePage,ContactPage,AboutPage
  ],
  imports: [
    BrowserModule,
    HttpClientModule, 
    IonicModule.forRoot(MyApp),
    AngularFireDatabaseModule,AngularFireAuthModule,
    AngularFireModule.initializeApp(FIREBASE_CONFIG)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    TabsPage
    ,HomePage,AboutPage,ContactPage,
  ],
  providers: [
    StatusBar,
    AngularFireAuth,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    CommonProvider
  ]
})
export class AppModule {}
