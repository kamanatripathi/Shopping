import { AngularFireModule } from 'angularfire2';
// for AngularFireDatabase
import { AngularFireDatabaseModule } from 'angularfire2/database';
// for AngularFireAuth
import { AngularFireAuthModule } from 'angularfire2/auth';
import { AngularFireAuth } from 'angularfire2/auth';
export const FIREBASE_CONFIG  = {
  apiKey: "AIzaSyA43L2LkaAtAzFS37mp1IH-D2FBPrBiGrA",
  authDomain: "bagcart-6e71a.firebaseapp.com",
  databaseURL: "https://bagcart-6e71a.firebaseio.com",
  projectId: "bagcart-6e71a",
  storageBucket: "bagcart-6e71a.appspot.com",
  messagingSenderId: "480906454949"
};