export interface Name{
    name: string;
    contact: number;
    address: string;
}