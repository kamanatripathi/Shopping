import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
@IonicPage()
@Component({
  selector: 'page-product-cat',
  templateUrl: 'product-cat.html',})
export class ProductCatPage {
 public Products: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, public http : HttpClient) {}
  ionViewDidLoad() {
    var navID = this.navParams.get('ID');
    console.log(navID);
    const body = {
      'pid' : navID}
   this.http.post<any>("http://balajiinteriors.biz/KAMANA/post_data.php",body).subscribe(data => {
    this.Products = data;
    console.log(data);}) }
  ProductClick(item){
    this.navCtrl.push('ProductDetailsPage',{
      item : item });
    console.log(item);}}
