import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
import { ProductDetailsPage } from '../product-details/product-details';
import { ProductCatPage } from '../product-cat/product-cat';
@Component({
  selector: 'page-about',
  templateUrl: 'about.html'
})
export class AboutPage {
  public Products : any;
  constructor(public navCtrl: NavController, private http : HttpClient) {}
  ionViewDidLoad(){
    console.log("About Page Loaded");
    this.http.get('http://balajiinteriors.biz/KAMANA/').subscribe(data =>{
      this.Products = data;
      console.log(data); });}
  rucksack(){
    this.navCtrl.push('ProductCatPage',{
      "ID" : 3  })}
  bag(){
    this.navCtrl.push('ProductCatPage',{
      "ID" : 1 })}
  trolley(){
    this.navCtrl.push('ProductCatPage',{
      "ID" : 2})}
  sling(){
    this.navCtrl.push('ProductCatPage',{
      "ID" : 7})}
  messenger(){
    this.navCtrl.push('ProductCatPage',{
      "ID" : 4})}
  wallet(){
    this.navCtrl.push('ProductCatPage',{
      "ID" : 5})}
  hand(){
    this.navCtrl.push('ProductCatPage',{
      "ID" : 6 })}
  cluthes(){
    this.navCtrl.push('ProductCatPage',{
      "ID" : 8 })}
  ProductClick(item){
    this.navCtrl.push('ProductDetailsPage',{
      item : item   });
    console.log(item); }}
