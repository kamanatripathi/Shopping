import { SignupPage } from './../signup/signup';
import { HomePage } from './../home/home';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
  import { FormBuilder, FormGroup, Validators } from '@angular/forms';
  import { User } from '../../models/User';
  import{AngularFireAuth} from "angularfire2/auth";

import { AngularFireDatabase } from 'angularfire2/database';
@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',})
export class LoginPage {
  public submitAttempt: boolean = false;
  public loginError: boolean = false;
  public loginMessage;
  user={} as User;
  constructor(public toastCtrl: ToastController,public navCtrl: NavController, public navParams: NavParams,public formBuilder: FormBuilder,private afauth:AngularFireAuth) {  }
async loginUser(user:User) {
  let toast = this.toastCtrl.create({
    message: "Failure to connect/Invalid Credentials",
    duration: 3000,
    position: 'top'
  });
  try{
    const result = await this.afauth.auth.signInWithEmailAndPassword(this.user.email, this.user.password);
console.log(result);
    if(result){
      let toast = this.toastCtrl.create({
        message: ( "Log In Successfully"),
        duration: 1500
      });
this.navCtrl.setRoot(HomePage);
      console.log('Got it');
      toast.present();}}
  catch(e){
    toast.present();
  console.log('Nope');   }
}
signup(){
  this.navCtrl.push('SignupPage');
}
}
