import { Component} from '@angular/core';
import { IonicPage, NavController,  NavParams, ToastController} from 'ionic-angular';
import { User } from '../../models/User';
import{AngularFireAuth} from "angularfire2/auth";
/**
 * Generated class for the SignupPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html',
})
export class SignupPage {
user = {} as User;
  constructor(public toastCtrl: ToastController,public navCtrl: NavController, public navParams: NavParams,private afauth:AngularFireAuth) {}


 async home (user:User) {
try{
  const result=await this.afauth.auth.createUserWithEmailAndPassword(this.user.email,this.user.password);
  console.log(result);
  let toast = this.toastCtrl.create({
    message: ( "Account Created"),
    duration: 1500
  });
  console.log("Created");
}

catch(e){
console.log(e);   
  }
}
login() {
    this.navCtrl.push('LoginPage');
    
  }

}
