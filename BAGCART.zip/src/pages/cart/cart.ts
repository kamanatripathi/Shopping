import { CheckoutPage } from './../checkout/checkout';
import { CommonProvider } from './../../providers/common/common';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController, ToastController } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
@IonicPage()
@Component({
  selector: 'page-cart',
  templateUrl: 'cart.html',
})
export class CartPage {
  showEmptyCartMessage: boolean = false;
Products:any;
  total: any; 
  cart : any = [] ;
  constructor(public navCtrl: NavController, public navParams: NavParams,   public common : CommonProvider    ,   private http : HttpClient, public viewCtrl: ViewController, public toastController: ToastController) {
    this.http.get('http://balajiinteriors.biz/KAMANA/').subscribe(data =>{
      this.Products = data;
      console.log(data); });
    this.total = 0.0;}
 ionViewDidLoad() {
    this.cart = this.common.cart;
    console.log('ionViewDidLoad CartPage');  }
  closeModal(){
    this.viewCtrl.dismiss();}
  checkout(){
    this.navCtrl.push('CheckoutPage' );}}
