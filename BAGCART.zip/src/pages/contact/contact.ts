
import { Name } from './../../models/name_interface';
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { AngularFireDatabase, AngularFireList} from 'angularfire2/database';
import {AngularFireModule} from 'angularfire2';
@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'})
export class ContactPage {
  public Products : any;  
form: AngularFireList<Name[]>;
  constructor(public navCtrl: NavController,private afdb: AngularFireDatabase,public NavParams: NavParams  ) {
  }
ionViewDidLoad() {
  console.log('ionViewDidLoad ProductDetailsPage');}}