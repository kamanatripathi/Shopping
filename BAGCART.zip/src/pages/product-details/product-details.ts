import { CommonProvider } from './../../providers/common/common';
import { Component } from '@angular/core';
import { IonicPage, NavController, ToastController, NavParams } from 'ionic-angular';
@IonicPage()
@Component({
  selector: 'page-product-details',
  templateUrl: 'product-details.html',})
export class ProductDetailsPage {
  public Product : any;
  public cart : any = [];
  constructor(public navCtrl: NavController, public toastCtrl: ToastController, public common : CommonProvider,  public navParams: NavParams) {
    var item = this.navParams.get('item');
    this.Product = item;
    console.log(item);}
  ionViewDidLoad() {
    console.log('ionViewDidLoad ProductDetailsPage');}
  presentToast() {
    let toast = this.toastCtrl.create({
      message: 'Added to cart successfully',
      duration: 1500});
    toast.present();}
Cart(){
  this.common.cart.push(this.Product);
  this.presentToast();
    console.log(this.common.cart); }
cart2(){
  this.navCtrl.push('CartPage');}
Wish(){
  this.navCtrl.push('ContactPage');}
addtoWishlist(){}
  ProductClick(item){
    this.navCtrl.push('ProductDetailsPage',{
      item : item });
    console.log(item); }}
