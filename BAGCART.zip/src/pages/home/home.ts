import { Component } from '@angular/core';
import { NavController, ToastController } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  public Products : any;
  constructor(public navCtrl: NavController, private http : HttpClient,private toast:ToastController) {
    this.http.get('http://balajiinteriors.biz/KAMANA/').subscribe(data =>{
      this.Products = data;
      console.log(data);
    });}
  male(){
    this.navCtrl.push('GenderProductsPage',{
    'Gender' : "male"
      });
  }
  female(){
    this.navCtrl.push('GenderProductsPage',{
    'Gender' : "female"      
    }); }
login()
{ 
  this.navCtrl.push('LoginPage');
}
cart(){
  this.navCtrl.push('CartPage');
}
}
