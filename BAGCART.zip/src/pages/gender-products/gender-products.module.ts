import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GenderProductsPage } from './gender-products';

@NgModule({
  declarations: [
    GenderProductsPage,
  ],
  imports: [
    IonicPageModule.forChild(GenderProductsPage),
  ],
})
export class GenderProductsPageModule {}
