import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
@IonicPage()
@Component({
  selector: 'page-gender-products',
  templateUrl: 'gender-products.html',})
export class GenderProductsPage {
  public Products: any;
  public sec : any;
  constructor(public navCtrl: NavController, public navParams: NavParams, public http : HttpClient) {} 
  ionViewDidLoad() {
  var navID = this.navParams.get('ProductName');
  var gender = this.navParams.get('Gender');
  this.sec = gender;
  console.log(gender);
      this.http.get("http://balajiinteriors.biz/KAMANA/").subscribe(data => {
      this.Products = data;
      console.log(data);})
    console.log('ionViewDidLoad GenderProductsPage'); }
  ProductClick(item){
    this.navCtrl.push('ProductDetailsPage',{
      item : item});
    console.log(item);}}
